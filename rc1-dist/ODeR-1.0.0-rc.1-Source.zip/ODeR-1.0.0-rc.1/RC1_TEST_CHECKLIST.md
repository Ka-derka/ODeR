# ODeR 1.0.0-rc.1 test checklist

Use a copy of important ODeR data while testing. Record the Windows version, display scale, ODeR edition, and whether the test was a clean install or an upgrade.

## Test record

- [ ] Tester:
- [ ] Date:
- [ ] Windows version:
- [ ] Display scale: 100% / 125% / 150% / other:
- [ ] Edition: Portable / Installed / Source
- [ ] Test path: Clean / Upgrade from version:

## Critical smoke test

- [ ] ODeR launches and shows `1.0.0-rc.1` in Settings.
- [ ] Launching ODeR a second time focuses the existing window instead of opening another instance.
- [ ] Existing libraries appear without a long interface freeze.
- [ ] A new library can be added from a valid directory URL.
- [ ] Its root can be indexed and browsed after disconnecting from the network.
- [ ] A file downloads successfully to the configured download folder.
- [ ] Closing and reopening ODeR preserves libraries, tabs, settings, favorites, and the download queue.

## Portable edition

- [ ] The ZIP extracts without requiring installation.
- [ ] `portable.flag`, `LICENSE`, and `THIRD_PARTY_NOTICES.md` are present beside the executable.
- [ ] First launch creates the writable `data` folder beside the executable.
- [ ] Moving the complete extracted folder preserves its data and still launches correctly.
- [ ] Updating does not overwrite the current portable data folder automatically.

## Installed edition

- [ ] The installer upgrades an older installed ODeR without losing user data.
- [ ] Start menu and optional desktop shortcuts work.
- [ ] Writable data is stored under `%LOCALAPPDATA%\ODeR`, not under Program Files.
- [ ] Double-clicking an `.oder` file opens it in the installed application.
- [ ] Uninstall removes application files while intentionally retaining user data.

## Home, library tiles, and navigation

- [ ] Library tiles remain square and reflow cleanly when the window is narrowed or widened.
- [ ] Tile titles, hosts, counts, and state text remain legible in Light, Graphite, Midnight, OLED, and a custom theme.
- [ ] The three-dot control has no unwanted arrow and opens a menu containing Settings, Information, and Export `.oder`.
- [ ] There are no duplicate Add library or Settings controls at the top of Home.
- [ ] Add library, New tab, Favorites, and More use the full sidebar width consistently.
- [ ] New tab and Favorites remain above More.
- [ ] More expands downward and remembers its state after restart.
- [ ] Activity, Changes, Storage, Logs, and Settings appear only in the expanded section.
- [ ] Downloads opens from the lower-right status-bar button and its count changes with queued/active work.
- [ ] Tab close buttons are on the right, have a visible button boundary, and close only the intended tab.

## Browsing and crawling

- [ ] Invalid, unreachable, redirected, and authenticated directory URLs show useful errors.
- [ ] Common Apache, nginx, Caddy, and plain link listings produce correct names, folders, sizes, and types.
- [ ] Encoded names and nested paths display correctly without unsafe parent or cross-origin links.
- [ ] Update folder begins promptly and Activity stays responsive throughout it.
- [ ] Starting a crawl does not automatically switch the current view to Activity.
- [ ] Folder update, Grow, Resume, Incremental update, and Full update complete successfully.
- [ ] Stop interrupts a crawl cleanly and Resume continues useful work.
- [ ] A failed or stopped full update restores the previous complete index.
- [ ] Name, Size, and Type columns are resizable and stay usable at multiple display scales.
- [ ] Download and Copy link actions stay vertically centered and aligned at the far-right edge.

## Search, favorites, changes, and storage

- [ ] Search finds expected cached files and folders without a network connection.
- [ ] Library, file/folder, type, and size filters combine correctly.
- [ ] A saved search can be created, reopened, and removed.
- [ ] Folder and search favorites survive restart and open the correct target.
- [ ] Changes correctly shows added, removed, and modified entries after an update.
- [ ] Storage reports plausible sizes and repair, compact, and clear actions affect only the selected library.

## Downloads

- [ ] A single file downloads to `<download folder>/<library>/<source folders>/<file>`.
- [ ] A folder group expands in the background and preserves the complete source hierarchy.
- [ ] Expanding a site's download list stays open while the page refreshes.
- [ ] Pause, Resume, Retry, Cancel, and group controls affect the intended items.
- [ ] Progress, speed, ETA, and group totals update without freezing the interface.
- [ ] A partially downloaded file resumes after forcing ODeR closed and reopening it.
- [ ] Existing completed files are kept or replaced according to the selected preference.
- [ ] Reserved names, very long names, duplicate normalized names, and traversal-like names cannot escape or overwrite another destination.

## `.oder` packages

- [ ] Definition-only export imports as a library that still needs indexing.
- [ ] Full-index export imports as an immediately browsable offline library.
- [ ] Subtree export contains only the selected branch and opens correctly.
- [ ] Dragging an `.oder` anywhere onto ODeR begins import.
- [ ] Double-click/file-association opening forwards the package to an already running instance.
- [ ] Importing a duplicate offers both copy and replace conflict choices.
- [ ] Copy creates an independent library; replace preserves the expected local settings.
- [ ] Compare reports meaningful differences without importing.
- [ ] A package with a changed manifest, hash, unexpected file, unsafe path, corrupt database, wrong URL, or unsupported format is rejected before existing data changes.
- [ ] A configured or advertised hosted `.oder` index loads, and an unchanged one uses conditional refresh.
- [ ] A failed hosted-index replacement restores the last complete cached index.

## Themes, input, and accessibility

- [ ] Light theme has no unreadable dark controls or low-contrast text.
- [ ] Custom color swatches open the native chooser and matching hex fields update correctly.
- [ ] Text and controls remain usable at 100%, 125%, 150%, and 200% scaling where available.
- [ ] Keyboard shortcuts, Tab focus order, Enter, Escape, and context menus work on the main workflows.
- [ ] Long library names, filenames, translations/Unicode, and narrow windows do not cover important controls.

## In-app updates

- [ ] From an older installed version, Preview channel detects `1.0.0-rc.1` after the GitHub prerelease is published.
- [ ] Stable channel does not offer RC1.
- [ ] Release notes display before download.
- [ ] Installer and portable assets are selected for the correct edition.
- [ ] A valid asset passes SHA-256 verification; a deliberately mismatched checksum is rejected and the partial download is removed.
- [ ] Active crawl/download work causes installer handoff to wait for a safe idle point.
- [ ] Skip version and Clear skipped version behave correctly.
- [ ] View releases remains available after a failed check or download.

## Recovery and diagnostics

- [ ] Legacy 0.x settings, profiles, favorites, crawl state, package history, and download queue migrate successfully.
- [ ] A last-known-good JSON backup is recovered after an advanced test with a deliberately truncated copied state file.
- [ ] A full-update checkpoint left by an advanced forced-termination test is restored on next launch.
- [ ] Logs → Export diagnostics creates a readable ZIP.
- [ ] Default diagnostics do not contain library names, URLs, filenames, cached listings, or downloaded data.
- [ ] Optional recent logs are included only after the privacy warning is accepted.

## Release assets and sign-off

- [ ] `ODeR-Portable.exe`, `ODeR-Portable.zip`, `ODeR Installer.exe`, source ZIP, and `SHA256SUMS.txt` are present.
- [ ] Every binary/ZIP checksum matches `SHA256SUMS.txt`.
- [ ] The GitHub tag is exactly `v1.0.0-rc.1` and the release is marked as a pre-release.
- [ ] No critical data-loss, security, migration, startup, crawl, package, download, or update blocker remains.
- [ ] Known non-blocking issues are documented for RC2 or 1.0.

Final result: Pass / Pass with known issues / Fail

Blocking issues:

Non-blocking issues:
