# ODeR 0.21.0 — Structured Downloads & Diagnostics

ODeR 0.21.0 makes downloaded archives match the directories they came from and adds the support information needed to diagnose problems as the app moves closer to 1.0.

## Structured downloads

- Downloads now recreate the source directory's complete folder hierarchy beneath a folder for that ODeR directory.
- URL-encoded names such as `Season%201` are saved naturally as `Season 1`.
- Individual files, selected-file groups, and complete folder downloads all use the same structure.
- Download destinations remain stable after restarting ODeR or renaming a saved directory.
- Existing 0.20 download queues are migrated without moving their current partial or completed files.
- Unsafe path components, Windows-reserved names, very long names, and normalized-name collisions are handled safely.
- The **Keep existing completed files** preference now avoids another network request when the destination already exists.
- Structured relative paths are visible directly in the Downloads page.

## Faster large folder downloads

- Recursive folder expansion now runs outside the interface thread.
- Large folder and selected-file batches are added with one queue update instead of rewriting the complete queue for every file; batch pause, resume, retry, removal, and completed-item cleanup are similarly consolidated.
- The 100,000-entry benchmark now covers recursive download expansion and recovery-checkpoint performance.

## Support diagnostics

- Added **Logs → Export diagnostics**.
- The report includes application/runtime versions, state schemas, anonymous cache totals, SQLite health, pending recovery checkpoints, and download status totals.
- Directory names and URLs, filenames, cached listings, and downloaded files are excluded from the standard report.
- Recent logs can be included optionally after a privacy warning, since logs may contain URLs or filenames.

## Reliability and compatibility

- Added download-queue schema 2 with automatic migration from 0.20.
- Added regression coverage for structured destinations, unsafe paths, collisions, batch performance behavior, existing-file handling, schema migration, and diagnostics privacy.
- Windows and Linux automated tests and the Windows portable-build smoke check remain part of every change.

Installed editions can update through **Settings → Application updates**. Portable users can extract the new portable ZIP over the application files while keeping their existing `data` folder.

Canonical release tag: `v0.21.0`
